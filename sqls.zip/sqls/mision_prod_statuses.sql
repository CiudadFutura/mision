INSERT INTO mision_prod.statuses (name, created_at, updated_at) VALUES ('Agendado', '2016-07-31 22:56:56', '2016-07-31 22:56:59');
INSERT INTO mision_prod.statuses (name, created_at, updated_at) VALUES ('En espera', '2016-07-31 22:57:15', '2016-07-31 22:57:16');
INSERT INTO mision_prod.statuses (name, created_at, updated_at) VALUES ('Asignado', '2016-07-31 22:57:45', '2016-07-31 22:57:46');
INSERT INTO mision_prod.statuses (name, created_at, updated_at) VALUES ('Entregado', '2016-07-31 22:58:10', '2016-07-31 22:58:11');
INSERT INTO mision_prod.statuses (name, created_at, updated_at) VALUES ('Completado', '2016-07-31 22:58:48', '2016-07-31 22:58:50');