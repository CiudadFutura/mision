INSERT INTO mision_prod.sectors (name, description, created_at, updated_at) VALUES ('Almacén', '', '2016-07-30 13:06:42', '2016-07-30 13:06:42');
INSERT INTO mision_prod.sectors (name, description, created_at, updated_at) VALUES ('Frágil', '', '2016-07-30 13:06:55', '2016-07-30 13:06:55');
INSERT INTO mision_prod.sectors (name, description, created_at, updated_at) VALUES ('Frescos', '', '2016-07-30 13:07:12', '2016-07-30 13:07:12');
INSERT INTO mision_prod.sectors (name, description, created_at, updated_at) VALUES ('Frutas y Verduras', '', '2016-07-30 13:07:30', '2016-07-30 13:07:30');
INSERT INTO mision_prod.sectors (name, description, created_at, updated_at) VALUES ('Higiene y Limpieza', '', '2016-07-30 13:07:47', '2016-07-30 13:07:47');
INSERT INTO mision_prod.sectors (name, description, created_at, updated_at) VALUES ('Consumidores', '', '2016-08-04 01:39:10', '2016-08-04 01:39:10');