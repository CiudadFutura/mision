INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (153, 8478, 0, 214.34, 'Transacción por el pedido N° 7916
Producto: Peceto Feteado	Cantidad: 2	Precio: $107,17
', '2016-09-08 23:10:47', '2016-09-10 15:54:45', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (329, 8811, 0, 160.07, 'Transacción por el pedido N° 8024
Producto: Tostaditas Clásicas	Cantidad: 2	Precio: $26,45
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:11:27', '2016-09-12 18:35:10', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (42, 8503, 0, 107.17, 'Transacción por el pedido N° 7858
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:11:55', '2016-09-10 18:52:02', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (49, 8792, 0, 107.17, 'Transacción por el pedido N° 7806
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:12:25', '2016-09-12 16:57:58', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (116, 8717, 0, 105.8, 'Transacción por el pedido N° 8085
Producto: Tostaditas Clásicas	Cantidad: 4	Precio: $26,45
', '2016-09-08 23:12:47', '2016-09-12 01:54:53', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (342, 8554, 0, 52.9, 'Transacción por el pedido N° 7772
Producto: Tostaditas Clásicas	Cantidad: 2	Precio: $26,45
', '2016-09-08 23:13:18', '2016-09-11 12:50:09', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (588, 10349, 0, 39.16, 'Transacción por el pedido N° 8032
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
Producto: Tapas de empanadas 12 u	Cantidad: 1	Precio: $12,71
', '2016-09-08 23:13:57', '2016-11-07 12:39:07', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (305, 8715, 0, 26.45, 'Transacción por el pedido N° 7884
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-08 23:16:59', '2016-09-12 01:49:34', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (322, 8602, 0, 32.4, 'Transacción por el pedido N° 7903
Producto: Triángulos de hojaldre	Cantidad: 2	Precio: $16,20
', '2016-09-08 23:17:34', '2016-09-11 19:19:00', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (330, 8587, 0, 26.45, 'Transacción por el pedido N° 7767
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-08 23:25:34', '2016-09-11 16:38:36', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (210, 8575, 0, 105.8, 'Transacción por el pedido N° 7845
Producto: Tostaditas Clásicas	Cantidad: 4	Precio: $26,45
', '2016-09-08 23:26:07', '2016-09-11 15:07:06', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (165, 8794, 0, 26.45, 'Transacción por el pedido N° 7852
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-08 23:26:53', '2016-09-12 17:17:37', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (182, 8665, 0, 24.68, 'Transacción por el pedido N° 7885
Producto: Hamburguesas de pollo	Cantidad: 1	Precio: $24,68
', '2016-09-08 23:31:13', '2016-09-11 23:58:45', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1076, 8866, 0, 107.17, 'Transacción por el pedido N° 7971
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:32:15', '2016-09-12 22:11:00', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (513, 8502, 0, 16.28, 'Transacción por el pedido N° 7784
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 2	Precio: $8,14
', '2016-09-08 23:32:59', '2016-09-10 18:49:44', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1048, 10987, 0, 82.42, 'Transacción por el pedido N° 7926
Producto: Roast beef	Cantidad: 1	Precio: $82.42', '2016-09-08 23:34:12', '2016-12-04 15:01:25', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (120, 8601, 0, 32.4, 'Transacción por el pedido N° 7770
Producto: Triángulos de hojaldre	Cantidad: 2	Precio: $16,20
', '2016-09-08 23:34:51', '2016-09-11 19:17:40', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (540, 8566, 0, 32.4, 'Transacción por el pedido N° 7706
Producto: Triángulos de hojaldre	Cantidad: 2	Precio: $16,20
', '2016-09-08 23:36:26', '2016-09-11 14:09:14', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (537, 8873, 0, 26.45, 'Transacción por el pedido N° 7891
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-08 23:36:56', '2016-09-12 22:20:16', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (193, 8489, 0, 107.17, 'Transacción por el pedido N° 8008
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:38:33', '2016-09-10 16:59:26', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (965, 8832, 0, 107.17, 'Transacción por el pedido N° 7835
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:39:04', '2016-09-12 20:09:26', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (968, 8720, 0, 16.2, 'Transacción por el pedido N° 7803
Producto: Triángulos de hojaldre	Cantidad: 1	Precio: $16,20
', '2016-09-08 23:39:37', '2016-09-12 01:57:21', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1046, 8552, 0, 69.71, 'Transacción por el pedido N° 7697
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
Producto: Mermelada Tomate 450 g	Cantidad: 1	Precio: $43,26
', '2016-09-08 23:41:43', '2016-09-11 03:49:55', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (316, 8890, 0, 107.17, 'Transacción por el pedido N° 8067
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:44:24', '2016-09-12 22:57:16', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (433, 8733, 0, 107.17, 'Transacción por el pedido N° 7881
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:46:02', '2016-09-12 02:53:22', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (531, 8870, 0, 26.45, 'Transacción por el pedido N° 7989
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-08 23:46:47', '2016-09-12 22:15:04', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (476, 8762, 0, 107.17, 'Transacción por el pedido N° 7957
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:47:53', '2016-09-12 13:13:07', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (468, 8595, 0, 56.63, 'Transacción por el pedido N° 6907
Producto: Supremas muslo 	Cantidad: 1	Precio: $56,63
', '2016-09-08 23:48:23', '2016-09-11 18:28:11', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (335, 8838, 0, 26.45, 'Transacción por el pedido N° 7933
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-08 23:48:47', '2016-09-12 20:29:11', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (29, 8614, 0, 26.45, 'Transacción por el pedido N° 7901
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-08 23:50:08', '2016-09-11 20:34:03', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (583, 9380, 0, 56.63, 'Transacción por el pedido N° 7857
Producto: Supremas muslo 	Cantidad: 1	Precio: $56,63
', '2016-09-08 23:51:04', '2016-10-08 23:44:37', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (218, 8728, 0, 34.5, 'Transacción por el pedido N° 7799
Producto: Pan para panchos 6 u	Cantidad: 2	Precio: $17,25
', '2016-09-08 23:53:45', '2016-09-12 02:22:09', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1093, 8824, 0, 107.17, 'Transacción por el pedido N° 7720
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:54:09', '2016-09-12 19:48:26', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (395, 9449, 0, 15.57, 'Transacción por el pedido N° 8010
Producto: Salsa Golf Cada Día x 250 gs	Cantidad: 1	Precio: $15,57
', '2016-09-08 23:54:35', '2016-10-09 21:43:56', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (130, 8867, 0, 15.57, 'Transacción por el pedido N° 8068
Producto: Salsa Golf Cada Día x 250 gs	Cantidad: 1	Precio: $15,57
', '2016-09-08 23:55:57', '2016-09-12 22:11:31', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (38, 8863, 0, 107.17, 'Transacción por el pedido N° 7637
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:56:29', '2016-09-12 22:05:26', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (484, 8808, 0, 163.8, 'Transacción por el pedido N° 8022
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
Producto: Supremas muslo 	Cantidad: 1	Precio: $56,63
', '2016-09-08 23:57:07', '2016-09-12 18:15:07', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (156, 8856, 0, 160.07, 'Transacción por el pedido N° 8087
Producto: Tostaditas Clásicas	Cantidad: 2	Precio: $26,45
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-08 23:57:31', '2016-09-12 21:39:20', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (274, 8743, 0, null, '', '2016-09-08 23:57:52', '2016-09-12 04:31:25', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (283, 9383, 0, 16.28, 'Transacción por el pedido N° 7886
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 2	Precio: $8,14
', '2016-09-08 23:58:11', '2016-10-09 00:05:04', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (517, 8813, 0, 70.4, 'Transacción por el pedido N° 8026
Producto: Milanesas de soja	Cantidad: 2	Precio: $35,20
', '2016-09-09 00:00:25', '2016-09-12 18:47:33', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (509, 13109, 0, 113.3, 'Transacción por el pedido N° 7998
Producto: Canasta de Quesos La Resistencia	Cantidad: 1	Precio: $113,30
', '2016-09-09 00:00:47', '2017-03-13 21:16:07', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (105, 8492, 0, 107.17, 'Transacción por el pedido N° 8079
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-09 00:01:16', '2016-09-10 17:26:37', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (184, 8688, 0, 16.2, 'Transacción por el pedido N° 7898
Producto: Triángulos de hojaldre	Cantidad: 1	Precio: $16,20
', '2016-09-09 00:01:39', '2016-09-12 00:51:49', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (162, 8466, 0, 55.55, 'Transacción por el pedido N° 7751
Producto: Pan con cereales y semillas	Cantidad: 1	Precio: $55,55
', '2016-09-09 00:03:02', '2016-09-10 13:28:29', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1217, 8876, 0, 13.09, 'Transacción por el pedido N° 7817
Producto: Copos de Maíz (cereal) Azucarados 240 gr.	Cantidad: 1	Precio: $13,09
', '2016-09-09 00:03:31', '2016-09-12 22:30:41', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (366, 8692, 0, 26.45, 'Transacción por el pedido N° 8017
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-09 00:03:52', '2016-09-12 00:56:02', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (388, null, 0, 26.45, 'Transacción por el pedido N° 8095
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-09 00:04:15', '2016-09-09 00:04:15', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (471, 8580, 0, 210.78, 'Transacción por el pedido N° 7934
Producto: Canasta Hamburguesas	Cantidad: 1	Precio: $47,15
Producto: Canasta Pre-pizzas	Cantidad: 1	Precio: $56,46
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-09 00:05:11', '2016-09-11 15:32:28', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (528, 8731, 0, 159.2, 'Transacción por el pedido N° 8040
Producto: Salsa Golf Cada Día x 250 gs	Cantidad: 1	Precio: $15,57
Producto: Triángulos de hojaldre	Cantidad: 2	Precio: $16,20
Producto: Canasta Picada	Cantidad: 1	Precio: $111,23
', '2016-09-09 00:05:46', '2016-09-12 02:30:56', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (488, 9327, 0, 52.9, 'Transacción por el pedido N° 7752
Producto: Tostaditas Clásicas	Cantidad: 2	Precio: $26,45
', '2016-09-09 00:07:33', '2016-10-08 13:14:31', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (371, null, 0, 142.48, 'Transacción por el pedido N° 7844
Producto: Uxmal Malbec 750 cc	Cantidad: 2	Precio: $71,24
', '2016-09-09 00:09:43', '2016-09-09 00:09:43', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (180, 9429, 0, 113.26, 'Transacción por el pedido N° 7985
Producto: Supremas muslo 	Cantidad: 2	Precio: $56,63
', '2016-09-09 00:10:49', '2016-10-09 16:01:36', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (202, 8740, 0, 107.17, 'Transacción por el pedido N° 8011
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-09 00:11:30', '2016-09-12 03:34:18', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (205, 8696, 0, 38.85, 'Transacción por el pedido N° 7746
Producto: Azúcar mascabo	Cantidad: 1	Precio: $38,85
', '2016-09-09 00:11:50', '2016-09-12 01:05:24', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (447, 8714, 0, 38.85, 'Transacción por el pedido N° 7692
Producto: Azúcar mascabo	Cantidad: 1	Precio: $38,85
', '2016-09-09 00:12:25', '2016-09-12 01:48:45', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (200, 8568, 0, 31.14, 'Transacción por el pedido N° 7712
Producto: Salsa Golf Cada Día x 250 gs	Cantidad: 2	Precio: $15,57
', '2016-09-09 00:13:09', '2016-09-11 14:31:17', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (82, 9114, 0, 57.49, 'Transacción por el pedido N° 8208
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 1	Precio: $8,14
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 00:14:29', '2016-09-19 11:03:31', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1273, 9871, 0, 49.35, 'Transacción por el pedido N° 8199
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 00:14:54', '2016-10-17 01:07:56', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (658, 9064, 0, 57.49, 'Transacción por el pedido N° 8315
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 1	Precio: $8,14
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 00:16:14', '2016-09-19 00:02:54', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (235, 8763, 0, 26.45, 'Transacción por el pedido N° 7666
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
', '2016-09-09 00:16:51', '2016-09-12 13:18:19', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (271, 8849, 0, 161.12, 'Transacción por el pedido N° 7861
Producto: Cañoncitos	Cantidad: 1	Precio: $27,50
Producto: Tostaditas Clásicas	Cantidad: 1	Precio: $26,45
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-09 00:17:51', '2016-09-12 21:21:18', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (499, 8852, 0, 107.17, 'Transacción por el pedido N° 8043
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-09 00:18:35', '2016-09-12 21:30:01', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (492, 8864, 0, 15, 'Transacción por el pedido N° 8084
Producto: Pan Panchos	Cantidad: 1	Precio: $15', '2016-09-09 12:44:56', '2016-09-12 22:05:55', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (120, 8601, 0, 16.85, 'Transacción por el pedido N° 7770
Producto: Pre pizza	Cantidad: 1	Precio: $16.85', '2016-09-09 12:50:16', '2016-09-11 19:17:40', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1290, 8750, 0, 21.7, 'Transacción por el pedido N° 7679
Producto: Aceitunas Verdes- Canasta Picada	Cantidad: 1	Precio: $21.70', '2016-09-09 13:39:18', '2016-09-12 11:54:52', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (485, 8448, 0, 107.17, 'Transacción por el pedido N° 7701
Producto: Peceto Feteado	Cantidad: 1	Precio: $107,17
', '2016-09-09 13:50:09', '2016-09-09 23:29:02', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (813, 9129, 0, 90.48, 'Transacción por el pedido N° 8387
Producto: Vacío	Cantidad: 1	Precio: $90,48
', '2016-09-09 13:54:59', '2016-09-19 12:56:59', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (751, 9148, 0, 139.83, 'Transacción por el pedido N° 8405
Producto: Vacío	Cantidad: 1	Precio: $90,48
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 13:55:30', '2016-09-19 14:39:47', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (511, 9849, 0, 106.76, 'Transacción por el pedido N° 8344
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 2	Precio: $8,14
Producto: Vacío	Cantidad: 1	Precio: $90,48
', '2016-09-09 13:56:08', '2016-10-16 23:22:29', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (692, 9093, 0, 148.05, 'Transacción por el pedido N° 8404
Producto: Mozzarella La Resistencia 400g	Cantidad: 3	Precio: $49,35
', '2016-09-09 13:56:59', '2016-09-19 02:24:05', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (181, 8999, 0, 49.35, 'Transacción por el pedido N° 8377
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 13:57:44', '2016-09-18 12:52:40', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1338, 9985, 0, 49.35, 'Transacción por el pedido N° 8407
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 13:58:06', '2016-10-17 18:51:48', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (608, 9050, 0, 8.14, 'Transacción por el pedido N° 8294
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 1	Precio: $8,14
', '2016-09-09 13:58:27', '2016-09-18 23:09:16', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (168, 8911, 0, 8.14, 'Transacción por el pedido N° 8213
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 1	Precio: $8,14
', '2016-09-09 13:58:52', '2016-09-16 23:27:21', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (413, 9120, 0, 13.09, 'Transacción por el pedido N° 8209
Producto: Copos de Maíz (cereal) Azucarados 240 gr.	Cantidad: 1	Precio: $13,09
', '2016-09-09 13:59:16', '2016-09-19 12:06:29', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (752, 8959, 0, 49.35, 'Transacción por el pedido N° 8221
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 13:59:39', '2016-09-17 17:07:52', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1180, 10623, 0, 90.48, 'Transacción por el pedido N° 8363
Producto: Vacío	Cantidad: 1	Precio: $90,48
', '2016-09-09 14:00:02', '2016-11-13 13:46:25', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (661, 9089, 0, 38.12, 'Transacción por el pedido N° 8397
Producto: Miel 500 g.	Cantidad: 1	Precio: $38,12
', '2016-09-09 14:00:25', '2016-09-19 02:01:43', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1432, 9163, 0, 35.2, 'Transacción por el pedido N° 8288
Producto: Pan molde de Salvado	Cantidad: 1	Precio: $35,20
', '2016-09-09 14:00:56', '2016-09-19 17:50:04', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1383, 9039, 0, 11.5, 'Transacción por el pedido N° 8249
Producto: Salchchicas SWIFT x 6 unid.	Cantidad: 1	Precio: $11,50
', '2016-09-09 14:01:28', '2016-09-18 22:15:14', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (373, 11739, 0, 90.48, 'Transacción por el pedido N° 8196
Producto: Vacío	Cantidad: 1	Precio: $90,48
', '2016-09-09 14:04:19', '2017-01-14 19:57:46', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (696, 11756, 0, 37.35, 'Transacción por el pedido N° 8193
Producto: Biscuits 120 grs. SMAMS	Cantidad: 1	Precio: $25,85
Producto: Salchchicas SWIFT x 6 unid.	Cantidad: 1	Precio: $11,50
', '2016-09-09 14:05:40', '2017-01-14 22:13:07', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (693, 8986, 0, 51.7, 'Transacción por el pedido N° 8282
Producto: Aceto Balsamico	Cantidad: 1	Precio: $51,70
', '2016-09-09 14:11:29', '2016-09-18 00:05:25', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1124, 9076, 0, 90.48, 'Transacción por el pedido N° 8323
Producto: Vacío	Cantidad: 1	Precio: $90,48
', '2016-09-09 14:12:17', '2016-09-19 00:59:20', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (478, 8948, 0, 49.35, 'Transacción por el pedido N° 8314
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 14:12:46', '2016-09-17 15:25:26', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (947, 9198, 0, 49.35, 'Transacción por el pedido N° 8326
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 14:13:15', '2016-09-19 21:12:16', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (313, 9028, 0, 49.35, 'Transacción por el pedido N° 8244
Producto: Mozzarella 400 grs	Cantidad: 1	Precio: $49.35', '2016-09-09 14:15:04', '2016-09-18 20:12:11', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (287, 9753, 0, 90.48, 'Transacción por el pedido N° 8144
Producto: Vacío	Cantidad: 1	Precio: $90,48
', '2016-09-09 14:15:57', '2016-10-15 16:11:38', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (652, 9012, 0, 24.42, 'Transacción por el pedido N° 8293
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 3	Precio: $8,14
', '2016-09-09 14:17:20', '2016-09-18 16:35:45', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (720, 8992, 0, 8.14, 'Transacción por el pedido N° 8178
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 1	Precio: $8,14
', '2016-09-09 14:18:05', '2016-09-18 02:04:29', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (490, 9019, 0, 49.35, 'Transacción por el pedido N° 8147
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 14:18:35', '2016-09-18 18:17:15', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (581, 9805, 0, 24.42, 'Transacción por el pedido N° 8205
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 3	Precio: $8,14
', '2016-09-09 14:18:59', '2016-10-16 02:44:47', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (773, 9860, 0, 230.31, 'Transacción por el pedido N° 8331
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
Producto: Vacío	Cantidad: 2	Precio: $90,48
', '2016-09-09 14:19:25', '2016-10-17 00:20:25', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (808, 9117, 0, 41.4, 'Transacción por el pedido N° 8245
Producto: Pan de salvado 380 g	Cantidad: 1	Precio: $41,40
', '2016-09-09 14:20:05', '2016-09-19 11:45:33', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (169, 9044, 0, 13.09, 'Transacción por el pedido N° 8308
Producto: Copos de Maíz (cereal) Azucarados 240 gr.	Cantidad: 1	Precio: $13,09
', '2016-09-09 14:20:36', '2016-09-18 22:55:20', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (354, 9785, 0, 16.28, 'Transacción por el pedido N° 8190
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 2	Precio: $8,14
', '2016-09-09 14:20:56', '2016-10-15 22:56:01', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (618, 8898, 0, 49.35, 'Transacción por el pedido N° 8195
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 14:21:27', '2016-09-16 21:41:31', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (758, 9045, 0, 49.35, 'Transacción por el pedido N° 8336
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 14:21:57', '2016-09-18 22:57:42', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (891, 9218, 0, 13.09, 'Transacción por el pedido N° 8130
Producto: Copos de Maíz (cereal) Azucarados 240 gr.	Cantidad: 1	Precio: $13,09
', '2016-09-09 14:23:00', '2016-09-19 22:25:21', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (496, 9153, 0, 13.09, 'Transacción por el pedido N° 8351
Producto: Copos de Maíz (cereal) Azucarados 240 gr.	Cantidad: 1	Precio: $13,09
', '2016-09-09 14:23:34', '2016-09-19 15:40:54', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (657, 8996, 0, 21.23, 'Transacción por el pedido N° 8423
Producto: Copos de Maíz (cereal) tradicionales	Cantidad: 1	Precio: $8,14
Producto: Copos de Maíz (cereal) Azucarados 240 gr.	Cantidad: 1	Precio: $13,09
', '2016-09-09 14:24:21', '2016-09-18 03:52:10', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (748, 10864, 0, 49.35, 'Transacción por el pedido N° 8386
Producto: Mozzarella La Resistencia 400g	Cantidad: 1	Precio: $49,35
', '2016-09-09 14:25:05', '2016-11-14 22:25:34', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (1231, 8963, 0, null, '', '2016-09-13 23:27:35', '2016-09-17 18:51:32', null);
INSERT INTO mision_prod.transactions (account_id, pedido_id, transaction_type, amount, description, created_at, updated_at, parent_id) VALUES (630, 9212, 0, null, '', '2016-09-14 00:00:58', '2016-09-19 22:09:58', null);