INSERT INTO mision_prod.seed_migration_data_migrations (version, runtime, migrated_on) VALUES ('20150619153632', 6, '2015-06-27 20:27:22');
INSERT INTO mision_prod.seed_migration_data_migrations (version, runtime, migrated_on) VALUES ('20150619204936', 2, '2015-06-27 20:27:24');
INSERT INTO mision_prod.seed_migration_data_migrations (version, runtime, migrated_on) VALUES ('20150625143232', 12, '2015-06-27 20:27:37');
INSERT INTO mision_prod.seed_migration_data_migrations (version, runtime, migrated_on) VALUES ('20150628211552', 0, '2015-06-28 21:35:26');
INSERT INTO mision_prod.seed_migration_data_migrations (version, runtime, migrated_on) VALUES ('20150628212509', 1, '2015-06-28 21:39:09');
INSERT INTO mision_prod.seed_migration_data_migrations (version, runtime, migrated_on) VALUES ('20150703150548', 0, '2015-07-03 20:24:45');